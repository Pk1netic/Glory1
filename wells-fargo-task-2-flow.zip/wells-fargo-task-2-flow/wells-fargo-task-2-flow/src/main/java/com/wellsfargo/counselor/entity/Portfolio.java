package com.wellsfargo.counselor.entity;

import jakarta.persistence.Column;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Portfolio {
	
	@Id
	@GeneratedValue()
	private long portfolioID;
	
	@ManyToOne()
	private long clientID;
	
	@Column(nullable = false)
	private int day;
	
	@Column(nullable = false)
	private int month;
	
	@Column(nullable = false)
	private int year;
	
	@Column(nullable = false)
	private  String date;
	
	protected Portfolio () {

    }

    public Portfolio(long clientID, int day, int month, int year) {
        this.clientID = clientID;
        this.day = day;
        this.month = month;
        this.year = year;
        this.date =  day + "/" + month + "/" + year;
    }
    
    public Long getclientID() {
    	return this.clientID;
    }
	
    public Long getportofolioID() {
    	return this.portfolioID;
    }
    
    public void setDate(int day, int month, int year) {
    	this.day = day;
    	this.month = month;
        this.year = year;
    	this.date = day + "/" + month + "/" + year;
    }
    
    public String getDate() {
    	return this.date;
    }
}
