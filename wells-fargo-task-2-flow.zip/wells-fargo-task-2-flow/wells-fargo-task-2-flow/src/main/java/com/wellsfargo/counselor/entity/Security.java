package com.wellsfargo.counselor.entity;

import jakarta.persistence.Column;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity
public class Security {
	
	@Id
	@GeneratedValue()
	private long securityID;
	
	@ManyToOne()
	private long portfolioID;
	
	@Column(nullable = false)
	private String name;
	
	@Column(nullable = false)
	private String category;
	
	@Column(nullable = false)
	private double purchasePrice;
	
	@Column(nullable = false)
	private  String purchaseDate;
	
	@Column(nullable = false)
	private  int quantity;
	
	protected Security() {

    }
	
	Security(long portfolioID,String name,String category, double purchasePrice, String purchaseDate, int quantity){
		this.portfolioID = portfolioID;
		this.name = name;
		this.category=category;
		this.purchasePrice=purchasePrice;
		this.purchaseDate=purchaseDate;
		this.quantity=quantity;
	}
	
	public long getSecurityID() {
		return securityID;
	}
	
	public long getPortfolioID() {
		return portfolioID;
	}
	
	public void setName(String name) {
		this.name=name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setCategory(String category) {
		this.category=category;
	}
	
	public String getCategory() {
		return category;
	}
	
	public void setPurchasePrice(double price) {
		this.purchasePrice = price;
	}
	
	public String getPurchasePrice() {
		return "£"+purchasePrice;
	}
	
	public void setPurchaseDate(int day, int month, int year) {
		this.purchaseDate = day+"/"+month+"/"+year;
	}
	public String getPurchaseDate() {
		return purchaseDate;
	}
	
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	public int getQuantity() {
		return quantity;
	}
}
